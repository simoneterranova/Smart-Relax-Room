import json
import requests
import cherrypy
import datetime
import pytz
import time
from utils import (
    load_json_file
)

service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')

class ThingSpeakAPI:
    def __init__(self, config):
        self.api_key = config['key']
        print('key:', self.api_key)
        self.url = config['url']
        print('URL:', self.url)
        self.url_channels = config['url_channels']
        self.url_channels_string = config['url_channels_string']
        print('Channels:',self.url_channels)
    
    def get_channel_list(self):
        url = f"{self.url_channels}?api_key={self.api_key}"
        print(url)
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error: {response.status_code} - {response.text}")
            return None

    def create_channel(self, owner):
        response = requests.post(
            self.url_channels,
            json={
                "api_key": self.api_key,
                "name": owner,
                "field1": "Temperature",
                "field2": "Humidity",
                "field3": "Noise",
                "field4": "Brightness",
                "public_flag": True
            }
        )
        if response.status_code == 200:
            data = response.json()
            return data["id"], data['api_keys'][0]['api_key']
        else:
            print(f"Error during the creation of '{owner}': {response.text}")
            return None, None

    def post_data(self, channel_id, write_key, field_data):
        headers = {'Content-type': 'application/json', 'Accept': 'raw'}
        current_time = (datetime.datetime.now(pytz.timezone('Europe/Rome')) - datetime.timedelta(hours=2)).strftime("%d-%m-%Y %H:%M:%S")

        data_upload = json.dumps({
            "api_key": write_key,
            "channel_id": channel_id,
            "created_at": current_time,
            "field1": field_data.get('field1'),
            "field2": field_data.get('field2'),
            "field3": field_data.get('field3'),
            "field4": field_data.get('field4')
        })
        
        try:
            response = requests.post(url=self.url, data=data_upload, headers=headers)
            response.raise_for_status()
            print("Data sent to ThingSpeak successfully!")
        except requests.RequestException as e:
            print(f"Error sending data to ThingSpeak: {e}")
    
    def delete_channel(self, channel_id):
        url = f"{self.url_channels_string}/{channel_id}?api_key={self.api_key}"
        print(url)
        response = requests.delete(url)
        if response.status_code == 200:
            print(f"Channel {channel_id} deleted successfully.")
            return True
        else:
            print(f"Error deleting channel {channel_id}: {response.status_code} - {response.text}")
            return False

class ThingSpeakService:
    exposed = True
    def __init__(self, config):
        self.api = ThingSpeakAPI(config)
        self.channel_list = self.api.get_channel_list()
        self.config = config

    @cherrypy.tools.json_out()
    @cherrypy.tools.json_in()
    def GET(self, *uri, **parameters):
        if len(uri) == 0:
            return {"status": "Error", "message": "No action specified"}
        
        action = uri[1]
        if action == "channels":
            return self.api.get_channel_list()
        
        elif action == 'return_last_data':
            channel_id = parameters.get('channel_id')
            read_key = parameters.get('read_key')
            url = self.config["url_feed"]
            url = url.replace("channel_id", channel_id)
            params = {
                'api_key': read_key,
                'results': 20  # Numero di risultati desiderati
            }
            try:
                response = requests.get(url, params=params)
                response.raise_for_status()
                data = response.json()
                feeds = data.get('feeds', [])
                
                # Dizionario per memorizzare i valori
                values_dict = {
                    'temperature': [],
                    'humidity': [],
                    'brightness': [],
                    'noise': []
                }
                # Aggiungi i valori al dizionario con nomi dei campi personalizzati
                for entry in feeds:
                    if 'field1' in entry and entry['field1'] is not None:
                        values_dict['temperature'].append(entry['field1'])
                    if 'field2' in entry and entry['field2'] is not None:
                        values_dict['humidity'].append(entry['field2'])
                    if 'field3' in entry and entry['field3'] is not None:
                        values_dict['noise'].append(entry['field3'])
                    if 'field4' in entry and entry['field4'] is not None:
                        values_dict['brightness'].append(entry['field4'])
                return values_dict
            except requests.RequestException as e:
                print(f"Error fetching data: {e}")
                return None
        else:
            return {"status": "Error", "message": "Unsupported action"}

    @cherrypy.tools.json_out()
    @cherrypy.tools.json_in()

    def POST(self, *uri):
        input_data = cherrypy.request.json
        action = uri[1] if len(uri) > 0 else None
        print('URI:', uri)
        print(f"Received action: {action}")
        print(f"Input data: {input_data}")
        
        if action == "create_channel":
            owner = input_data.get('owner')
            if not owner:
                return {"status": "Error", "message": "Owner not provided"}
            
            channel_id, write_key = self.api.create_channel(owner)
            if channel_id and write_key:
                return {"status": "Success", "channel_id": channel_id, "write_key": write_key}
            else:
                return {"status": "Error", "message": "Failed to create channel"}

        elif action == "post_data":
            channel_id = input_data.get('channel_id')
            write_key = input_data.get('write_key')
            field_data = {
                "field1": input_data.get("field1"),
                "field2": input_data.get("field2"),
                "field3": input_data.get("field3"),
                "field4": input_data.get("field4")
            }
            
            if not channel_id or not write_key:
                return {"status": "Error", "message": "Missing channel ID or write key"}
            
            self.api.post_data(channel_id, write_key, field_data)
            return {"status": "Success", "message": "Data posted to ThingSpeak"}
    
    @cherrypy.tools.json_out()
    @cherrypy.tools.json_in()
    def DELETE(self, *uri, **parameters):
        print(uri)
        action = uri[1]
        if action == "delete_channel":
            channel_id = parameters.get('channel_id')
            if not channel_id:
                return {"status": "Error", "message": "Channel ID not provided"}
            success = self.api.delete_channel(channel_id)
            if success:
                return {"status": "Success", "message": f"Channel {channel_id} deleted"}
            else:
                return {"status": "Error", "message": "Failed to delete channel"}


# Main function that starts the ThingSpeak service with CherryPy
if __name__ == "__main__":
    # Registrazione nel service catalog del servizio Thingspeak
    service_catalog_info_name = "settings_service_catalog.json"
    service_catalog_info = load_json_file(service_catalog_info_name)
    conf_thingspeak_file_json = load_json_file("conf_thingspeak_REST.json")
    post_string = f'{service_catalog_url}/microservice'
    response = requests.post(post_string, json.dumps(conf_thingspeak_file_json))
    print(conf_thingspeak_file_json["ip_address"])

    # CherryPy configuration
    conf = {
        "/": {
            "request.dispatch": cherrypy.dispatch.MethodDispatcher(),
            "tools.sessions.on": True,
        }
    }
    
    TS = ThingSpeakService(conf_thingspeak_file_json)
    cherrypy.tree.mount(TS, "/", conf)
    cherrypy.config.update(conf)
    cherrypy.config.update({"server.socket_host": conf_thingspeak_file_json["ip_address"]})
    cherrypy.config.update({"server.socket_port": int(conf_thingspeak_file_json["ip_port"])})
    cherrypy.engine.start()
    # while True:
    #     rcm.removeDevices()
    #     time.sleep(120)
    cherrypy.engine.block()