import json
import requests
from MyMQTT import MyMQTT
import sys
import datetime
import pytz
import time
from utils import (
    load_json_file,
    get_resource_catalog,
    get_owners,
    select_owner,
    baseTopic_service_resource
)

class ThingSpeakAPI:
    def __init__(self, config):
        self.api_key = config['key']
        self.url = config['url']
        self.url_channels = config['url_channels']
    
    def get_channel_list(self):
        url = f"https://api.thingspeak.com/channels.json?api_key={self.api_key}"
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error: {response.status_code} - {response.text}")
            return None

    def create_channel(self, owner):
        response = requests.post(
            self.url_channels,
            json={
                "api_key": self.api_key,
                "name": owner,
                "field1": "Temperature",
                "field2": "Humidity",
                "field3": "Noise",
                "field4": "Brightness",
                "public_flag": True
            }
        )
        if response.status_code == 200:
            data = response.json()
            return data["id"], data['api_keys'][0]['api_key']
        else:
            print(f"Error during the creation of '{owner}': {response.text}")
            return None, None

class ThinkSpeak:
    def __init__(self, clientID, broker, port, channel, write_key):
        self.client = MyMQTT(clientID, broker, port, self)
        self.channel = channel
        self.write_key = write_key
        self.ID = f"{self.channel}_TS-Adaptor"
        self.type = "TS-Adaptor"
        self.field1_data = None
        self.field2_data = None
        self.field3_data = None
        self.field4_data = None

    def start(self, topic):
        self.topic = topic
        self.client.start()
        self.client.mySubscribe(self.topic)

    def stop(self):
        self.client.stop()

    def notify(self, topic, msg):
        data = json.loads(msg.decode('utf8'))
        print('Receiving measurement from topic ', topic)
        for operation in data["e"]:
            if operation["type"] == "temperature":
                self.field1_data = operation["value"]
            elif operation["type"] == "humidity":
                self.field2_data = operation["value"]
            elif operation["type"] == "noise":
                self.field3_data = operation["value"]
            elif operation["type"] == "brightness":
                self.field4_data = operation["value"]

def get_owner(service_catalog_info):
    service_catalog_info = load_json_file("service_catalog_info.json")
    resource_catalog_info = get_resource_catalog(service_catalog_info)
    list_owners = get_owners(resource_catalog_info)
    name_owner, _ = select_owner(list_owners)
    return name_owner

# Modifica la funzione main per accettare il nome dell'owner come argomento opzionale
def main(owner_name=None):
    headers = {'Content-type': 'application/json', 'Accept': 'raw'}
    service_catalog_info = load_json_file("service_catalog_info.json")
    resource_catalog_info = get_resource_catalog(service_catalog_info)
    rc_ip = resource_catalog_info["ip_address"]
    rc_ip_port = resource_catalog_info["ip_port"]

    think_config = load_json_file("conf_thingspeak.json")
    thingspeak_api = ThingSpeakAPI(think_config)
    channel_list = thingspeak_api.get_channel_list()

    # Se owner_name non viene fornito, recuperalo usando get_owner()
    if not owner_name:
        owner_name = get_owner(service_catalog_info)

    # Usa l'owner_name che ora dovrebbe essere settato
    new_channel_name = owner_name
    if not new_channel_name:
        print("Error: Could not retrieve or determine the owner.")
        sys.exit()

    existing_channel = next((element for element in channel_list if new_channel_name == element["name"]), None)

    if existing_channel:
        time.sleep(1)
        print(f'Channel "{new_channel_name}" already created.')
        time.sleep(2)
        channel_id = existing_channel["id"]
        write_key = existing_channel["api_keys"][0]["api_key"]
    else:
        print('Channel not found. Creating a new channel...')
        channel_id, write_key = thingspeak_api.create_channel(new_channel_name)
        output = {
            "owner": new_channel_name,
            "channel": {
                "api_key": write_key,
                "channel_name": new_channel_name,
                "channel_id": channel_id,
            }
        }
        try:
            post_string = f'http://{rc_ip}:{rc_ip_port}/thingspeak'
            response = requests.post(post_string, json=output)
        except requests.RequestException as e:
            print(f"Error posting to ThingSpeak: {e}")
            
        if not channel_id or not write_key:
            print("Error creating channel.")
            sys.exit()

    service_basetopic, resource_basetopic = baseTopic_service_resource(service_catalog_info, resource_catalog_info)
    topic_to_subscribe = f"{service_basetopic}{resource_basetopic}/{new_channel_name}/post_processing/mean_value/+"
    tp = ThinkSpeak(new_channel_name, think_config["broker"], think_config["port1"], channel_id, write_key)
    tp.start(topic_to_subscribe)

    count = 0
    t = 0

    while t < 80:
        current_time = (datetime.datetime.now(pytz.timezone('Europe/Rome')) - datetime.timedelta(hours=2)).strftime("%d-%m-%Y %H:%M:%S")

        data_upload = json.dumps({
            "api_key": tp.write_key,
            "channel_id": tp.channel,
            "created_at": current_time,
            "entry_id": count,
            "field1": tp.field1_data,
            "field2": tp.field2_data,
            "field3": tp.field3_data,
            "field4": tp.field4_data
        })
        try:
            response = requests.post(url=think_config["url"], data=data_upload, headers=headers)
            response.raise_for_status()
            print("INFORMATION SENT TO THINGSPEAK!")
            print(f'Sending new data to ThingSpeak every 30 seconds...')
        except requests.RequestException as e:
            print(f"Error sending data to ThingSpeak: {e}")

        time.sleep(30)
        count += 1
        t += 1

    tp.stop()

if __name__ == "__main__":
    main()  # Esecuzione senza owner_name --> scelto dall'utente
