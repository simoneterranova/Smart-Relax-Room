# utils.py
import json
import requests
import sys
import os

service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')
def load_json_file(file_path):
    """Carica le informazioni da un file JSON."""
    try:
        with open(file_path, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"Error: The file {file_path} was not found.")
        sys.exit(1)
    except json.JSONDecodeError:
        print("Error: The file is not a valid JSON file.")
        sys.exit(1)
        
def extract_value(message):
    """Estrae il valore dal messaggio JSON."""
    message_str = message.decode('utf-8')
    message_json = json.loads(message_str)
    data = message_json["e"]
    value = data[0]["value"]
    return value

def extract_sensor_name(message):
    """Estrae il nome del sensore dal messaggio JSON."""
    message_str = message.decode('utf-8')
    message_json = json.loads(message_str)
    data = message_json["bn"]
    parts = data.split('/')
    name = parts[-1]
    return name

def extract_sensor_type(message):
    """Estrae il nome del sensore dal messaggio JSON."""
    message_str = message.decode('utf-8')
    message_json = json.loads(message_str)
    data = message_json["e"]
    name = data[0]["type"]
    return name

def extract_RelaxRoom_name(message):
    """Estrae il nome della Relax Room dal messaggio JSON."""
    message_str = message.decode('utf-8')
    message_json = json.loads(message_str)
    data = message_json["bn"]
    parts = data.split('/')
    name = parts[3]
    return name

def get_resource_catalog(service_catalog_info):
    """Ottiene e seleziona il resource catalog dal service catalog."""
    service_get_string = f"{service_catalog_url}/res_cat"
    try:
        list_resources = requests.get(service_get_string).json()
        if len(list_resources) == 1:
            return list_resources[0]
        else:
            for i in range(len(list_resources)):
                print(f" {i + 1} ---> {list_resources[i]['name_resource_catalog']}")
            while True:
                try:
                    input_value = input('Enter the room associated to resource catalog: ').strip()
                    if not input_value:
                        print('Error: No input provided, please enter a number.')
                        continue
                    number_catalog = int(input_value)
                    if number_catalog < 1 or number_catalog > len(list_resources):
                        print('Error: Number out of range. Please select a valid room number.')
                    else:
                        return list_resources[number_catalog - 1]
                except ValueError:
                    print('Error: Invalid input, please enter a valid number.')
    except requests.exceptions.RequestException as e:
        print(f"Error: Could not retrieve data from service catalog. {e}")
        sys.exit(1)

def get_owners(res_catalog):
    """Ottiene e seleziona gli owners dal resource catalog."""
    catalog_get_string = f"{resource_catalog_url}/allowners"
    try:
        return requests.get(catalog_get_string).json()
    except requests.exceptions.RequestException as e:
        print(f"Error: Could not retrieve data from resource catalog. {e}")
        sys.exit(1)

def get_owners_DC(res_catalog):
    """Ottiene e seleziona gli owners dal resource catalog."""
    catalog_get_string = f"{resource_catalog_url}/allownersDC"
    try:
        return requests.get(catalog_get_string).json()
    except requests.exceptions.RequestException as e:
        print(f"Error: Could not retrieve data from resource catalog. {e}")
        sys.exit(1)
        
def get_owners_withoutDC(res_catalog):
    """Ottiene e seleziona gli owners dal resource catalog."""
    catalog_get_string = f"{resource_catalog_url}/allownersWithoutDC"
    try:
        return requests.get(catalog_get_string).json()
    except requests.exceptions.RequestException as e:
        print(f"Error: Could not retrieve data from resource catalog. {e}")
        sys.exit(1)

def select_owner(list_owners):
    """Permette all'utente di selezionare un owner."""
    print('\nWhich relax room do you want to select?')
    N_rooms = len(list_owners)
    for i in range(N_rooms):
        print(f" {i + 1} ---> {list_owners[i]}")
    while True:
        try:
            input_value = input('Enter the number associated to the owner: ').strip()
            if not input_value:
                print('Error: No input provided, please enter a number.')
                continue
            number_owner = int(input_value)
            if number_owner < 1 or number_owner > N_rooms:
                print('Error: Number out of range. Please select a valid room number.')
            else:
                return list_owners[number_owner - 1], number_owner
        except ValueError:
            print('Error: Invalid input, please enter a valid number.')

def get_sensor_name():
    """Permette all'utente di inserire il nome del sensore."""
    while True:
        input_name_sensor = input('Enter the name of the sensor: ').strip()
        if not input_name_sensor:
            print('Error: No input provided. Please enter a valid sensor name.')
        else:
            print(f"Name of sensor: {input_name_sensor} \n")
            return input_name_sensor

def show_available_measure(res_catalog, owner, measure):
        get_string = f"{resource_catalog_url}/alldevices?owner={owner}&sensor_type={measure}"
        response = requests.get(get_string)
        sensors = response.json()
        if len(sensors) > 0:
            return True
        else:
            return False

def check_device_registration(res_catalog, name_owner, sensor_name):
    """Verifica se il dispositivo è già registrato."""
    try:
        catalog_get_check_string = f"{resource_catalog_url}/device?owner={name_owner}&ID={sensor_name}"
        response = requests.get(catalog_get_check_string)
        response.raise_for_status()
        # Interpretazione della risposta JSON
        result = response.json()
        # Check per vedere se il dispositivo è già associato
        if result.get("status") == "error" and "already registered" in result.get("message", ""):
            return True
        elif result.get("status") == "success":
            return False
        else:
            # Gestione di eventuali altri stati o messaggi inattesi
            print(f"Risposta inattesa: {result}")
            return False
    except requests.RequestException as e:
        print(f"Errore nella verifica del dispositivo: {e}")
        return False

def check_user_registration(res_catalog_info, name_owner, user_id):
    request_string = f"{resource_catalog_url}/registeredUser?owner={name_owner}&user_id={user_id}"
    response = requests.get(request_string)
    if response.status_code == 200:
        print('User NOT registered')
        return False
    else:
        print('User already registered')
        return True
    
def get_ListUsers(res_catalog_info,name_owner):
    request_string = f"{resource_catalog_url}/allusers?owner={name_owner}"
    response = requests.get(request_string)
    users = response.json()
    user_to_modify = []
    for user in users:
        user_to_modify.append(user['user_id'])
    return user_to_modify
    
def baseTopic_service_resource(service_info, resource_info):
    try:
        # Request to get the base topic from the service
        get_string_basetopic = f"{service_catalog_url}/base_topic"
        basetopic_response = requests.get(get_string_basetopic)
        basetopic_response.raise_for_status()  # Raise an error for bad status codes
        
        # Convert the response JSON to a dictionary
        service_basetopic = basetopic_response.json()

        # Get the base topic for the resource
        resource_basetopic = resource_info['base_topic']
        return service_basetopic, resource_basetopic

    except requests.exceptions.RequestException as e:
        print(f"Error during request: {e}")
        # Handle or log the exception as needed
        return None, None

    except ValueError as e:
        print(f"Error decoding JSON: {e}")
        # Handle or log the exception as needed
        return None, None





