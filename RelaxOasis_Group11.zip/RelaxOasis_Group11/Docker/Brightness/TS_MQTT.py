import paho.mqtt.client as PahoMQTT
import json
import requests
import time
import signal
import sys
import os
from utils import load_json_file, get_resource_catalog

service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')

class ThinkSpeak:
    def __init__(self, clientID, broker, port, resource_catalog_info, topic, url):
        self.clientID = clientID
        self.broker = broker
        self.port = port
        self.resource_catalog_info = resource_catalog_info
        self._paho_mqtt = PahoMQTT.Client(clientID, True)

        # Register the callbacks
        self._paho_mqtt.on_connect = self.myOnConnect
        self._paho_mqtt.on_message = self.myOnMessageReceived

        # Store the topics and ThingSpeak configurations
        self.topic = topic
        self.url = url
        self.thingspeak_configs = {}
        self.initialize_configurations()

    def initialize_configurations(self):
        try:
            catalog_url = f"{resource_catalog_url}/thingspeakConfig"
            response = requests.get(catalog_url)
            response.raise_for_status()  # Solleva un'eccezione per eventuali errori HTTP
            # Il server restituisce direttamente le configurazioni pronte
            self.thingspeak_configs = response.json()
            print("Configurazioni ThingSpeak ricevute:", self.thingspeak_configs)

        except requests.RequestException as e:
            print(f"Errore durante la richiesta delle configurazioni: {e}")
            self.thingspeak_configs = {}

    def start(self):
        self._paho_mqtt.connect(self.broker, self.port)
        self._paho_mqtt.loop_start()
        self._paho_mqtt.subscribe(self.topic, 0)
        print(f"Subscribed to topic: {self.topic}")

    def stop(self):
        self._paho_mqtt.unsubscribe(self.topic)
        self._paho_mqtt.loop_stop()
        self._paho_mqtt.disconnect()

    def myOnConnect(self, paho_mqtt, userdata, flags, rc):
        print(f"Connected to broker {self.broker}")

    def myOnMessageReceived(self, paho_mqtt, userdata, msg):
        print(f"Message received on topic: {msg.topic}")
        data = json.loads(msg.payload.decode('utf-8'))

        # Extract device connector ID from the topic
        device_connector_id = msg.topic.split('/')[3]  # Assuming the format: relax_room_iot/resource/{connector_id}/...

        # Update ThingSpeak configuration based on device connector ID
        ts_config = self.thingspeak_configs.get(device_connector_id)
        if not ts_config:
            print(f"No ThingSpeak config found for device: {device_connector_id}")
            print(f"Searching for configuration file...")
            self.initialize_configurations()
            return

        # Handle the data received
        field1_data = field2_data = field3_data = field4_data = None
        for operation in data["e"]:
            if operation["type"] == "temperature":
                field1_data = operation["value"]
            elif operation["type"] == "humidity":
                field2_data = operation["value"]
            elif operation["type"] == "noise":
                field3_data = operation["value"]
            elif operation["type"] == "brightness":
                field4_data = operation["value"]

        # Send the data to ThingSpeak
        self.send_to_thingspeak(ts_config['channel_id'], ts_config['write_key'], field1_data, field2_data, field3_data, field4_data)

    def send_to_thingspeak(self, channel_id, write_key, field1, field2, field3, field4):
        headers = {'Content-type': 'application/x-www-form-urlencoded'}
        data_upload = {
            "api_key": write_key,
            "field1": field1,
            "field2": field2,
            "field3": field3,
            "field4": field4
        }
        try:
            response = requests.post(url=f"{self.url}?api_key={write_key}", data=data_upload, headers=headers)
            if response.status_code == 200:
                print(f"Data sent to ThingSpeak channel {channel_id} successfully!")
            else:
                print(f"Failed to send data to ThingSpeak. Status code: {response.status_code}")
        except requests.RequestException as e:
            print(f"Error sending data to ThingSpeak: {e}")

def signal_handler(sig, frame):
    print('Stopping...')
    ts.stop()
    sys.exit(0)

if __name__ == "__main__":
    service_catalog_info_name = "settings_service_catalog.json"
    service_catalog_info = load_json_file(service_catalog_info_name)
    conf_thingspeak_file_json = load_json_file("conf_thingspeak.json")
    post_string = f'{service_catalog_url}/microservice'
    response = requests.post(post_string, json.dumps(conf_thingspeak_file_json))
    clientID = "ThinkSpeakClient"
    broker = conf_thingspeak_file_json["broker"]
    port = int(conf_thingspeak_file_json["port"])
    topic = conf_thingspeak_file_json["topic"]
    url = conf_thingspeak_file_json["url"]
    
    # Seleziona il resource catalog
    resource_catalog_info = get_resource_catalog(service_catalog_info)
    ts = ThinkSpeak(clientID, broker, port, resource_catalog_info, topic, url)
    
    # Register the signal handler
    signal.signal(signal.SIGINT, signal_handler)
    
    ts.start()
    print("START....")

    # Keep the program running
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        # Handle keyboard interrupt (Ctrl+C)
        print('Interrupt received, stopping...')
        ts.stop()
        sys.exit(0)