import paho.mqtt.client as PahoMQTT
import numpy as np
import json
import time
import requests
import os
from utils import load_json_file, get_resource_catalog, extract_sensor_type, extract_RelaxRoom_name
service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')

# Classes
class SensorControl:
    def __init__(self, clientID, subscribe_topic, publish_topic_alert, publish_topic_post_processing, broker, resource_catalog_info):
        self.clientID = clientID
        self._paho_mqtt = PahoMQTT.Client(clientID, True)
        self.last_20_values = {}
        self.threshold = 500  # Threshold for brightness 

        # Register callbacks
        self._paho_mqtt.on_connect = self.myOnConnect
        self._paho_mqtt.on_message = self.myOnMessageReceived

        self.subscribe_topic = subscribe_topic
        self.publish_topic_alert = publish_topic_alert
        self.publish_topic_post_processing = publish_topic_post_processing
        self.messageBroker = broker
        self.running = False
        self.resource_catalog_info = resource_catalog_info

    def start(self):
        try:
            self._paho_mqtt.connect(self.messageBroker, 1883)
            self._paho_mqtt.loop_start()
            self._paho_mqtt.subscribe(self.subscribe_topic, 0)
            self.running = True
        except Exception as e:
            print(f"Failed to connect or subscribe: {e}")

    def stop(self):
        self._paho_mqtt.unsubscribe(self.subscribe_topic)
        self._paho_mqtt.loop_stop()
        self._paho_mqtt.disconnect()
        self.running = False
        print(f'Subscriber {self.clientID} stopped')

    def myOnConnect(self, paho_mqtt, userdata, flags, rc):
        print("Connected with topic %s " % (self.subscribe_topic))

    def myOnMessageReceived(self, paho_mqtt, userdata, msg):
        """Handles incoming MQTT messages and updates last 20 values."""
        sensor_type = extract_sensor_type(msg.payload)
        name_owner = extract_RelaxRoom_name(msg.payload)
        self.publish_topic_alert = self.publish_topic_alert.replace('name_owner', name_owner)

        if sensor_type in msg.topic:
            try:
                # Fetch ThingSpeak configuration
                config_url = f"{resource_catalog_url}/thingspeak?device_connector_ID={name_owner}"
                response = requests.get(config_url)
                response.raise_for_status()
                config = response.json()
                channel_id = config.get("channel_id")
                read_key = config.get("read_key")

                if not channel_id or not read_key:
                    print(f"Invalid configuration for owner {name_owner}.")
                    return
                self.last_20_values[name_owner] = self.get_last_20_values(channel_id, read_key)
                self.publish_mean_value()
                
            except (json.JSONDecodeError, KeyError, requests.RequestException) as e:
                print(f"Failed to process message from {self.subscribe_topic}: {e}")

    def publish_mean_value(self):
        time.sleep(10)
        """Calculates and publishes the mean value of last 20 readings for each owner."""
        for owner, data in self.last_20_values.items():
            brightness = data["brightness"]
            if brightness:
                mean_value = round(np.mean(brightness), 3)
                print()
                print(f'--> Mean value of last 20 brightness readings for owner {owner}: {mean_value}')

                # Update the publish topic for the current owner
                publish_topic_post_processing = self.publish_topic_post_processing.replace('name_owner', owner)
                payload = json.dumps({
                    "bn": publish_topic_post_processing,
                    "e": [
                        {
                            "type": "brightness",
                            "unit": "lm",
                            "value": mean_value
                        }
                    ]
                })
                
                try:
                    self._paho_mqtt.publish(publish_topic_post_processing, payload)

                    if mean_value > self.threshold:
                        alert_payload = json.dumps({
                            "bn": publish_topic_post_processing,
                            "e": [
                                {
                                    "type": "brightness",
                                    "unit": "string",
                                    "value": 'ALERT!!! Mean brightness value over threshold!'
                                }
                            ]
                        })
                        try:
                            alert_topic = self.publish_topic_alert.replace('name_owner', owner)
                            self._paho_mqtt.publish(alert_topic, alert_payload)
                            print(f"Published alert message to topic: {alert_topic}")
                        except Exception as e:
                            print(f"Failed to publish alert message: {e}")

                except Exception as e:
                    print(f"Failed to publish mean value: {e}")

    def get_last_20_values(self, channel_id, read_key):
        """Fetches the last 20 values from ThingSpeak and initializes 'new_message'."""
        url = f'https://api.thingspeak.com/channels/{channel_id}/feeds.json'
        params = {
            'api_key': read_key,
            'results': 20  # Number of results desired
        }

        try:
            # Fetch data from ThingSpeak
            response = requests.get(url, params=params)
            response.raise_for_status()  # Raise an exception for HTTP errors

            # Parse JSON data
            data = response.json()
            feeds = data.get('feeds', [])

            # Dictionary to store values
            values_dict = {
                'temperature': [],
                'humidity': [],
                'brightness': [],
                'noise': []
            }

            # Process each feed entry
            for entry in feeds:
                for field_name in ['field1', 'field2', 'field3', 'field4']:
                    value = entry.get(field_name, None)

                    # Convert and store values
                    if value is not None:
                        try:
                            float_value = float(value)
                        except ValueError:
                            break
                        
                        if field_name == 'field1':
                            values_dict['temperature'].append(float_value)
                        elif field_name == 'field2':
                            values_dict['humidity'].append(float_value)
                        elif field_name == 'field3':
                            values_dict['noise'].append(float_value)
                        elif field_name == 'field4':
                            values_dict['brightness'].append(float_value)
            return values_dict

        except requests.RequestException as e:
            print(f"Error fetching data: {e}")
            return {
                'temperature': [],
                'humidity': [],
                'brightness': [],
                'noise': []
            }

if __name__ == "__main__":
    service_catalog_file = "settings_service_catalog.json"
    resource_catalog_file = "catalog_resource.json"
    conf_file_json = json.load(open("conf_control_brightness.json"))
    
    service_catalog_info = load_json_file(service_catalog_file)
    resource_catalog_info = get_resource_catalog(service_catalog_info)
    print(f"Resource catalog: {resource_catalog_info} \n")
    
    def initialize_configurations(resource_catalog_info):
        # Extract topics and ThingSpeak configurations
        thingspeak_configs = {}
        for ts_channel in resource_catalog_info['thingspeak']:
            # Ensure that the ThingSpeak configuration is correctly set
            device_connector_id = ts_channel['device_connector_id']
            thingspeak_configs[device_connector_id] = {
                "channel_id": ts_channel.get("channel_id", None),  # Use get to avoid KeyError
                "write_key": ts_channel.get("write_key", ts_channel.get("api_key", None))  # Fallback to api_key if write_key is missing
            }

    # Create an instance of SensorControl
    name_microservice = conf_file_json["name_microservice"]
    subscribe_topic = conf_file_json["subscribe_topic"]
    publish_topic_alert = conf_file_json["publish_topic_alert"]
    publish_topic_post_processing = conf_file_json["publish_topic_post_processing"]
    
    sensor_control = SensorControl(name_microservice, subscribe_topic, publish_topic_alert, publish_topic_post_processing, "test.mosquitto.org", resource_catalog_info)
    sensor_control.start()
    print('START....')

    running = True
    while running:
        time.sleep(300)
        
    sensor_control.stop()
