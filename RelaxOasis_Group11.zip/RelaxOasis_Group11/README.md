
RelaxOasis_Group11

Programming for IoT Applications

Welcome to the RelaxOasis Group11 repository! This project focuses on developing applications for the Internet of Things (IoT) to create a relaxing and automated environment.

Contents:

LINKS.txt: Contains links to our promotional and demo videos showcasing the project.

RelaxOasis-Group11.zip: Includes all the source code for the project, along with Docker files for easy deployment.

To clone the repository:git clone https://github.com/Ivdex229/RelaxOasis_Group11.git


